const domain = 'http://139.159.231.245'; // 正式
//const domain = 'http://192.168.24.17:8081'; // 正式

export default {

  //商品维护产品列表
  findItemSpu: `${domain}/aegFrontSystem/restServer/itemSpuService/findItemSpu`

}

